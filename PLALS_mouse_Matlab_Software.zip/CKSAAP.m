function test_data = CKSAAP(textdata)
% k-space feature extraction, k=0,1,2,3,4
k_space= importdata('k_space.mat'); 
for t=1:size(textdata,1)
    charV=textdata{t};
    for j=1:5
        for i=1:length(charV)-j
            w(i,1:j+1)=charV(i:i+j);
        end
        if j>1
           w(:,2:j)='_';
        end
        for k=1:length(charV)-j
            T(k,:,j)=1*strcmp(w(k,:),k_space);
        end
        clear w
    end
    test_data(t,:)=sum(sum(T),3);
end

