clc
clear
[Header Sequence]=fastaread('Xinput.fasta');
Header=cellstr(Header);
Sequence=cellstr(Sequence);
Sequence=Sequence';
Header=Header';
totnum=size(Header,1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Generating peptides %%%%%%%%%%%%%%%%%%%%%%%%%%%
i = 6; % Sliding window size was selected as 2*i+1= 13 in PLALS_mouse.
k = 1;
l = 1; 
for t=1:totnum
charV=Sequence{t};
for j = 1:length(charV)
if charV(j) == 'K'
result0(1:2*i+1) = 'X'; % To ensure the unified length of each peptides, an added residue ��X�� was used  
                        % to fill the corresponding position where there is no sufficient residues.
head = i + 1; 
tail = length(charV) - i; 
if j <= head & j > tail
result0(head-j+1:head-j+1+length(charV)-1) = charV(1:end);
elseif j < head & j < tail+1
    result0(i-j+2:2*i+1) = charV(1:i+j);
elseif j > tail & j > head
result0(1:i+length(charV)-j+1) = charV(j-i:end);
else
result0 = charV(j-i:j+i);
end
result1{k,1} = Header(t);  % Proteins ID
result1{k,2} = j;          % Lysine site
result1{k,3} = result0;    % Peptides that contain the central lysine and its ��6 flanking residues were extracted
k = k + 1;
l= l + 1;
end
end
end
%%%%%%%%%%%%%%%% k-space feature extraction, k=0,1,2,3,4 %%%%%%%%%%%%%%%%
test_data=CKSAAP(result1(:,3));  % Test data 
